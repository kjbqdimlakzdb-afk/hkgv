@echo off
chcp 65001 >nul
title Registre des maladies chroniques
cd /d "%~dp0"

set PY=
where python >nul 2>nul && set PY=python
if "%PY%"=="" where py >nul 2>nul && set PY=py
if "%PY%"=="" goto nopython

start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8080"
%PY% app.py
echo.
echo Le logiciel s'est arrete.
pause
exit /b

:nopython
echo.
echo  Python n'est pas installe sur cet ordinateur.
echo  Telechargez-le sur https://www.python.org/downloads/
echo  et COCHEZ la case "Add python.exe to PATH" pendant l'installation.
echo  Puis double-cliquez de nouveau sur start.bat.
echo.
pause
