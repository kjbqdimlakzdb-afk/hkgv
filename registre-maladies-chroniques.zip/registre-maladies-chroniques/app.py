#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Registre des maladies chroniques - Centre de santé
Serveur local multi-utilisateurs : Python 3.8+ (aucune bibliothèque externe) + base SQLite.

Lancement :  python app.py      (ou double-clic sur start.bat sous Windows)
Les autres postes du centre se connectent avec un navigateur : http://<adresse-du-poste-principal>:8080
"""
import csv
import datetime
import hashlib
import io
import json
import os
import re
import secrets
import socket
import sqlite3
import sys
import threading
import time
import traceback
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "donnees")
BACKUP_DIR = os.path.join(DATA_DIR, "sauvegardes")
DB_PATH = os.path.join(DATA_DIR, "registre.db")
PORT = int(os.environ.get("PORT", "8080"))
SESSION_TTL = 12 * 3600          # durée d'une session (12 h d'inactivité)
MAX_ROWS = 5000                  # lignes maximum affichées dans le registre
MIN_PASSWORD = 6

MEDICAMENTS_INITIAUX = [
    ("Amlodipine 5", "cp"), ("Ramipril 5", "cp"), ("Losartan 50", "cp"),
    ("Propranolol 40", "cp"), ("Méthyl dopa 250", "cp"), ("Furosémide 40", "cp"),
    ("Indapamide 1,5", "cp"), ("Insuline Rapide", "flacon"), ("Insuline Mixte", "flacon"),
    ("Insuline Semi lente", "flacon"), ("Gliclazide", "cp"), ("Glimépiride", "cp"),
    ("Métformine", "cp"), ("Aspirine", "cp"), ("Statine", "cp"),
]

ROLES = ("admin", "medecin", "infirmier")
PERMS = {
    "admin": {"*"},
    "medecin": {"patients.write", "disp.write", "disp.delete"},
    "infirmier": {"patients.write", "disp.write"},
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL,
    salt TEXT NOT NULL,
    pwd_hash TEXT NOT NULL,
    must_change INTEGER NOT NULL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS patients(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ipp TEXT,
    dossier_no TEXT,
    nom_prenom TEXT NOT NULL,
    sexe TEXT,
    date_naissance TEXT,
    telephone TEXT,
    adresse TEXT,
    diabete INTEGER NOT NULL DEFAULT 0,
    hta INTEGER NOT NULL DEFAULT 0,
    remarques TEXT,
    actif INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER,
    created_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_pat_ipp ON patients(ipp) WHERE ipp IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_pat_dossier ON patients(dossier_no) WHERE dossier_no IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_pat_nom ON patients(nom_prenom);
CREATE TABLE IF NOT EXISTS medicaments(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    unite TEXT NOT NULL DEFAULT 'cp',
    ordre INTEGER NOT NULL DEFAULT 0,
    actif INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS dispensations(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    date_disp TEXT NOT NULL,
    prochain_rdv TEXT,
    remarques TEXT,
    user_id INTEGER,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_disp_date ON dispensations(date_disp);
CREATE INDEX IF NOT EXISTS ix_disp_patient ON dispensations(patient_id, date_disp);
CREATE TABLE IF NOT EXISTS dispensation_items(
    dispensation_id INTEGER NOT NULL REFERENCES dispensations(id) ON DELETE CASCADE,
    medicament_id INTEGER NOT NULL REFERENCES medicaments(id),
    quantite INTEGER NOT NULL,
    PRIMARY KEY(dispensation_id, medicament_id)
);
CREATE TABLE IF NOT EXISTS journal(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    utilisateur TEXT,
    action TEXT NOT NULL,
    detail TEXT
);
"""


# --------------------------------------------------------------------------- utilitaires
class ApiError(Exception):
    def __init__(self, status, message, extra=None):
        super().__init__(message)
        self.status = status
        self.message = message
        self.extra = extra or {}


class Raw:
    """Réponse brute (fichier à télécharger, page HTML...)."""
    def __init__(self, data, ctype, filename=None):
        self.data, self.ctype, self.filename = data, ctype, filename


def now_str():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def hash_pwd(pwd, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pwd.encode("utf-8"), bytes.fromhex(salt), 200_000).hex()
    return salt, h


def check_pwd(pwd, salt, h):
    return secrets.compare_digest(hash_pwd(pwd, salt)[1], h)


def vdate(s):
    """Valide une date AAAA-MM-JJ (ou vide -> None)."""
    if s is None or str(s).strip() == "":
        return None
    try:
        return datetime.date.fromisoformat(str(s).strip()[:10]).isoformat()
    except ValueError:
        raise ApiError(400, "Date invalide : %s" % s)


def txt(v, maxlen=300):
    v = (v or "")
    if not isinstance(v, str):
        v = str(v)
    v = v.strip()
    return v[:maxlen] if v else None


def log(ctx_or_conn, user, action, detail=""):
    conn = ctx_or_conn.conn if isinstance(ctx_or_conn, Ctx) else ctx_or_conn
    name = user["username"] if user else None
    conn.execute("INSERT INTO journal(ts, utilisateur, action, detail) VALUES(?,?,?,?)",
                 (now_str(), name, action, detail))


def user_public(u):
    return {"id": u["id"], "username": u["username"], "full_name": u["full_name"],
            "role": u["role"], "must_change": bool(u["must_change"])}


def require(user, perm):
    p = PERMS.get(user["role"], set())
    if "*" not in p and perm not in p:
        raise ApiError(403, "Vous n'avez pas le droit d'effectuer cette action")


def unique_error(e):
    m = str(e)
    if "ipp" in m:
        return ApiError(409, "Cet IPP existe déjà dans le registre")
    if "dossier" in m:
        return ApiError(409, "Ce numéro de dossier existe déjà dans le registre")
    if "username" in m:
        return ApiError(409, "Cet identifiant existe déjà")
    return ApiError(409, "Doublon détecté")


# --------------------------------------------------------------------------- base de données
def init_db():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = db()
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM medicaments").fetchone()[0] == 0:
            for i, (nom, unite) in enumerate(MEDICAMENTS_INITIAUX, 1):
                conn.execute("INSERT INTO medicaments(nom, unite, ordre, actif) VALUES(?,?,?,1)", (nom, unite, i))
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            salt, h = hash_pwd("admin123")
            conn.execute("INSERT INTO users(username, full_name, role, salt, pwd_hash, must_change, active, created_at)"
                         " VALUES('admin','Administrateur','admin',?,?,1,1,?)", (salt, h, now_str()))
            print("  Compte créé :  identifiant « admin »  /  mot de passe « admin123 » (à changer à la première connexion)")
        conn.commit()
    finally:
        conn.close()


def copy_db(dest):
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(dest)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def auto_backup():
    """Une sauvegarde par jour dans donnees/sauvegardes (30 jours conservés)."""
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        dest = os.path.join(BACKUP_DIR, "registre_%s.db" % datetime.date.today().isoformat())
        if not os.path.exists(dest):
            copy_db(dest)
            files = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith("registre_") and f.endswith(".db"))
            for old in files[:-30]:
                os.remove(os.path.join(BACKUP_DIR, old))
    except Exception:
        traceback.print_exc()


def backup_loop():
    while True:
        time.sleep(3600)
        auto_backup()


# --------------------------------------------------------------------------- routage
ROUTES = []


def route(method, pattern, perm=None, public=False):
    rx = re.compile("^" + pattern + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn, perm, public))
        return fn
    return deco


class Ctx:
    def __init__(self, handler, conn, user, qs, body, args):
        self.handler, self.conn, self.user, self.qs, self.body, self.args = handler, conn, user, qs, body, args
        self.cookie = None  # valeur Set-Cookie éventuelle

    @property
    def ip(self):
        return self.handler.client_address[0]


FAILS = {}  # (ip, identifiant) -> (nombre d'échecs, verrouillé jusqu'à)
FAILS_LOCK = threading.Lock()


# --------------------------------------------------------------------------- authentification
@route("POST", r"/api/login", public=True)
def api_login(ctx):
    username = (ctx.body.get("username") or "").strip().lower()
    password = ctx.body.get("password") or ""
    key = (ctx.ip, username)
    with FAILS_LOCK:
        n, until = FAILS.get(key, (0, 0))
        if until > time.time():
            raise ApiError(429, "Trop de tentatives. Réessayez dans une minute.")
    u = ctx.conn.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
    if not u or not check_pwd(password, u["salt"], u["pwd_hash"]):
        with FAILS_LOCK:
            n = FAILS.get(key, (0, 0))[0] + 1
            FAILS[key] = (n, time.time() + 60 if n >= 5 else 0)
            if n >= 5:
                FAILS[key] = (0, time.time() + 60)
        raise ApiError(401, "Identifiant ou mot de passe incorrect")
    with FAILS_LOCK:
        FAILS.pop(key, None)
    ctx.conn.execute("DELETE FROM sessions WHERE expires < ?", (time.time(),))
    token = secrets.token_urlsafe(32)
    ctx.conn.execute("INSERT INTO sessions(token, user_id, expires) VALUES(?,?,?)",
                     (token, u["id"], time.time() + SESSION_TTL))
    ctx.cookie = "sid=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=%d" % (token, SESSION_TTL)
    log(ctx, u, "Connexion")
    return user_public(u)


@route("POST", r"/api/logout")
def api_logout(ctx):
    tok = ctx.handler.session_token()
    if tok:
        ctx.conn.execute("DELETE FROM sessions WHERE token=?", (tok,))
    ctx.cookie = "sid=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
    return {"ok": True}


@route("GET", r"/api/me")
def api_me(ctx):
    return user_public(ctx.user)


@route("POST", r"/api/password")
def api_password(ctx):
    old = ctx.body.get("ancien") or ""
    new = ctx.body.get("nouveau") or ""
    if not check_pwd(old, ctx.user["salt"], ctx.user["pwd_hash"]):
        raise ApiError(400, "L'ancien mot de passe est incorrect")
    if len(new) < MIN_PASSWORD:
        raise ApiError(400, "Le nouveau mot de passe doit contenir au moins %d caractères" % MIN_PASSWORD)
    if new in ("admin123", old):
        raise ApiError(400, "Choisissez un mot de passe différent")
    salt, h = hash_pwd(new)
    ctx.conn.execute("UPDATE users SET salt=?, pwd_hash=?, must_change=0 WHERE id=?", (salt, h, ctx.user["id"]))
    log(ctx, ctx.user, "Mot de passe modifié")
    return {"ok": True}


# --------------------------------------------------------------------------- utilisateurs (admin)
@route("GET", r"/api/users", perm="users")
def api_users(ctx):
    rows = ctx.conn.execute("SELECT id, username, full_name, role, active, must_change, created_at FROM users ORDER BY username")
    return [dict(r) for r in rows]


def _check_password_new(pw):
    if len(pw or "") < MIN_PASSWORD:
        raise ApiError(400, "Le mot de passe doit contenir au moins %d caractères" % MIN_PASSWORD)


@route("POST", r"/api/users", perm="users")
def api_user_create(ctx):
    b = ctx.body
    username = (b.get("username") or "").strip().lower()
    full_name = txt(b.get("full_name"), 100)
    role = b.get("role")
    if not re.match(r"^[a-z0-9._-]{3,30}$", username):
        raise ApiError(400, "Identifiant : 3 à 30 caractères (lettres, chiffres, point, tiret)")
    if not full_name:
        raise ApiError(400, "Le nom complet est obligatoire")
    if role not in ROLES:
        raise ApiError(400, "Rôle invalide")
    _check_password_new(b.get("password"))
    salt, h = hash_pwd(b["password"])
    try:
        cur = ctx.conn.execute("INSERT INTO users(username, full_name, role, salt, pwd_hash, must_change, active, created_at)"
                               " VALUES(?,?,?,?,?,1,1,?)", (username, full_name, role, salt, h, now_str()))
    except sqlite3.IntegrityError as e:
        raise unique_error(e)
    log(ctx, ctx.user, "Utilisateur créé", "%s (%s)" % (username, role))
    return {"id": cur.lastrowid}


@route("PUT", r"/api/users/(\d+)", perm="users")
def api_user_update(ctx):
    uid = int(ctx.args[0])
    b = ctx.body
    u = ctx.conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise ApiError(404, "Utilisateur introuvable")
    full_name = txt(b.get("full_name"), 100) or u["full_name"]
    role = b.get("role", u["role"])
    active = 1 if b.get("active", bool(u["active"])) else 0
    if role not in ROLES:
        raise ApiError(400, "Rôle invalide")
    if uid == ctx.user["id"] and (role != "admin" or not active):
        raise ApiError(400, "Vous ne pouvez pas retirer vos propres droits d'administrateur ni désactiver votre compte")
    ctx.conn.execute("UPDATE users SET full_name=?, role=?, active=? WHERE id=?", (full_name, role, active, uid))
    if b.get("password"):
        _check_password_new(b["password"])
        salt, h = hash_pwd(b["password"])
        ctx.conn.execute("UPDATE users SET salt=?, pwd_hash=?, must_change=1 WHERE id=?", (salt, h, uid))
        ctx.conn.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
    if not active:
        ctx.conn.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
    log(ctx, ctx.user, "Utilisateur modifié", u["username"])
    return {"ok": True}


# --------------------------------------------------------------------------- médicaments
@route("GET", r"/api/medicaments")
def api_meds(ctx):
    rows = ctx.conn.execute("SELECT id, nom, unite, ordre, actif FROM medicaments ORDER BY ordre, id")
    return [dict(r) for r in rows]


@route("POST", r"/api/medicaments", perm="meds")
def api_med_create(ctx):
    nom = txt(ctx.body.get("nom"), 80)
    unite = txt(ctx.body.get("unite"), 20) or "cp"
    if not nom:
        raise ApiError(400, "Le nom du médicament est obligatoire")
    ordre = ctx.conn.execute("SELECT COALESCE(MAX(ordre),0)+1 FROM medicaments").fetchone()[0]
    cur = ctx.conn.execute("INSERT INTO medicaments(nom, unite, ordre, actif) VALUES(?,?,?,1)", (nom, unite, ordre))
    log(ctx, ctx.user, "Médicament ajouté", nom)
    return {"id": cur.lastrowid}


@route("PUT", r"/api/medicaments/(\d+)", perm="meds")
def api_med_update(ctx):
    mid = int(ctx.args[0])
    m = ctx.conn.execute("SELECT * FROM medicaments WHERE id=?", (mid,)).fetchone()
    if not m:
        raise ApiError(404, "Médicament introuvable")
    b = ctx.body
    nom = txt(b.get("nom"), 80) or m["nom"]
    unite = txt(b.get("unite"), 20) or m["unite"]
    actif = 1 if b.get("actif", bool(m["actif"])) else 0
    try:
        ordre = int(b.get("ordre", m["ordre"]))
    except (TypeError, ValueError):
        raise ApiError(400, "Ordre invalide")
    ctx.conn.execute("UPDATE medicaments SET nom=?, unite=?, actif=?, ordre=? WHERE id=?", (nom, unite, actif, ordre, mid))
    log(ctx, ctx.user, "Médicament modifié", nom)
    return {"ok": True}


# --------------------------------------------------------------------------- patients
DERNIERE_VISITE = ("LEFT JOIN dispensations d ON d.id = (SELECT id FROM dispensations WHERE patient_id=p.id "
                   "ORDER BY date_disp DESC, id DESC LIMIT 1)")


def clean_patient(b):
    nom = txt(b.get("nom_prenom"), 120)
    if not nom:
        raise ApiError(400, "Le nom et prénom sont obligatoires")
    sexe = b.get("sexe") if b.get("sexe") in ("M", "F") else None
    return {
        "ipp": txt(b.get("ipp"), 40),
        "dossier_no": txt(b.get("dossier_no"), 40),
        "nom_prenom": nom,
        "sexe": sexe,
        "date_naissance": vdate(b.get("date_naissance")),
        "telephone": txt(b.get("telephone"), 40),
        "adresse": txt(b.get("adresse"), 200),
        "diabete": 1 if b.get("diabete") else 0,
        "hta": 1 if b.get("hta") else 0,
        "remarques": txt(b.get("remarques"), 1000),
    }


@route("GET", r"/api/patients")
def api_patients(ctx):
    q = (ctx.qs.get("q") or "").strip()
    where, params = [], []
    if not ctx.qs.get("inactifs"):
        where.append("p.actif=1")
    if q:
        where.append("(p.nom_prenom LIKE ? OR p.ipp LIKE ? OR p.dossier_no LIKE ? OR p.telephone LIKE ?)")
        params += ["%" + q + "%"] * 4
    w = ("WHERE " + " AND ".join(where)) if where else ""
    limit = 30 if ctx.qs.get("court") else 400
    rows = ctx.conn.execute(
        "SELECT p.*, d.date_disp AS derniere_visite, d.prochain_rdv FROM patients p %s %s ORDER BY p.nom_prenom LIMIT %d"
        % (DERNIERE_VISITE, w, limit), params)
    return [dict(r) for r in rows]


@route("POST", r"/api/patients", perm="patients.write")
def api_patient_create(ctx):
    p = clean_patient(ctx.body)
    try:
        cur = ctx.conn.execute(
            "INSERT INTO patients(ipp, dossier_no, nom_prenom, sexe, date_naissance, telephone, adresse, diabete, hta,"
            " remarques, actif, created_by, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?)",
            (p["ipp"], p["dossier_no"], p["nom_prenom"], p["sexe"], p["date_naissance"], p["telephone"], p["adresse"],
             p["diabete"], p["hta"], p["remarques"], ctx.user["id"], now_str()))
    except sqlite3.IntegrityError as e:
        raise unique_error(e)
    log(ctx, ctx.user, "Patient créé", "%s (IPP %s, dossier %s)" % (p["nom_prenom"], p["ipp"] or "-", p["dossier_no"] or "-"))
    return {"id": cur.lastrowid}


def _get_patient(conn, pid):
    p = conn.execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()
    if not p:
        raise ApiError(404, "Patient introuvable")
    return p


def _dispensations_of(conn, where, params):
    rows = [dict(r) for r in conn.execute(
        "SELECT d.id, d.patient_id, d.date_disp, d.prochain_rdv, d.remarques FROM dispensations d "
        "JOIN patients p ON p.id=d.patient_id WHERE " + where + " ORDER BY d.date_disp, d.id", params)]
    return rows


@route("GET", r"/api/patients/(\d+)")
def api_patient_get(ctx):
    pid = int(ctx.args[0])
    p = dict(_get_patient(ctx.conn, pid))
    disp = _dispensations_of(ctx.conn, "d.patient_id=?", (pid,))
    byid = {d["id"]: d for d in disp}
    for d in disp:
        d["items"] = {}
    for r in ctx.conn.execute("SELECT i.dispensation_id, i.medicament_id, i.quantite FROM dispensation_items i "
                              "JOIN dispensations d ON d.id=i.dispensation_id WHERE d.patient_id=?", (pid,)):
        byid[r["dispensation_id"]]["items"][r["medicament_id"]] = r["quantite"]
    disp.reverse()
    return {"patient": p, "dispensations": disp}


@route("PUT", r"/api/patients/(\d+)", perm="patients.write")
def api_patient_update(ctx):
    pid = int(ctx.args[0])
    _get_patient(ctx.conn, pid)
    p = clean_patient(ctx.body)
    actif = 1 if ctx.body.get("actif", True) else 0
    try:
        ctx.conn.execute(
            "UPDATE patients SET ipp=?, dossier_no=?, nom_prenom=?, sexe=?, date_naissance=?, telephone=?, adresse=?,"
            " diabete=?, hta=?, remarques=?, actif=? WHERE id=?",
            (p["ipp"], p["dossier_no"], p["nom_prenom"], p["sexe"], p["date_naissance"], p["telephone"], p["adresse"],
             p["diabete"], p["hta"], p["remarques"], actif, pid))
    except sqlite3.IntegrityError as e:
        raise unique_error(e)
    log(ctx, ctx.user, "Patient modifié", p["nom_prenom"])
    return {"ok": True}


@route("DELETE", r"/api/patients/(\d+)", perm="patients.delete")
def api_patient_delete(ctx):
    pid = int(ctx.args[0])
    p = _get_patient(ctx.conn, pid)
    ctx.conn.execute("DELETE FROM patients WHERE id=?", (pid,))
    log(ctx, ctx.user, "Patient supprimé", p["nom_prenom"])
    return {"ok": True}


# --------------------------------------------------------------------------- dispensations
def clean_disp(conn, b):
    try:
        pid = int(b.get("patient_id"))
    except (TypeError, ValueError):
        raise ApiError(400, "Choisissez un patient")
    _get_patient(conn, pid)
    date_disp = vdate(b.get("date_disp")) or datetime.date.today().isoformat()
    rdv = vdate(b.get("prochain_rdv"))
    items = {}
    for k, v in (b.get("items") or {}).items():
        try:
            mid, q = int(k), int(v)
        except (TypeError, ValueError):
            raise ApiError(400, "Quantité invalide")
        if q < 0 or q > 99999:
            raise ApiError(400, "Quantité invalide")
        if q > 0:
            if not conn.execute("SELECT 1 FROM medicaments WHERE id=?", (mid,)).fetchone():
                raise ApiError(400, "Médicament inconnu")
            items[mid] = q
    if not items:
        raise ApiError(400, "Saisissez au moins une quantité de médicament")
    return pid, date_disp, rdv, txt(b.get("remarques"), 500), items


@route("POST", r"/api/dispensations", perm="disp.write")
def api_disp_create(ctx):
    pid, date_disp, rdv, rem, items = clean_disp(ctx.conn, ctx.body)
    cur = ctx.conn.execute("INSERT INTO dispensations(patient_id, date_disp, prochain_rdv, remarques, user_id, created_at)"
                           " VALUES(?,?,?,?,?,?)", (pid, date_disp, rdv, rem, ctx.user["id"], now_str()))
    did = cur.lastrowid
    for mid, q in items.items():
        ctx.conn.execute("INSERT INTO dispensation_items(dispensation_id, medicament_id, quantite) VALUES(?,?,?)", (did, mid, q))
    p = _get_patient(ctx.conn, pid)
    log(ctx, ctx.user, "Dispensation enregistrée", "%s le %s" % (p["nom_prenom"], date_disp))
    return {"id": did}


@route("PUT", r"/api/dispensations/(\d+)", perm="disp.write")
def api_disp_update(ctx):
    did = int(ctx.args[0])
    if not ctx.conn.execute("SELECT 1 FROM dispensations WHERE id=?", (did,)).fetchone():
        raise ApiError(404, "Dispensation introuvable")
    pid, date_disp, rdv, rem, items = clean_disp(ctx.conn, ctx.body)
    ctx.conn.execute("UPDATE dispensations SET patient_id=?, date_disp=?, prochain_rdv=?, remarques=? WHERE id=?",
                     (pid, date_disp, rdv, rem, did))
    ctx.conn.execute("DELETE FROM dispensation_items WHERE dispensation_id=?", (did,))
    for mid, q in items.items():
        ctx.conn.execute("INSERT INTO dispensation_items(dispensation_id, medicament_id, quantite) VALUES(?,?,?)", (did, mid, q))
    p = _get_patient(ctx.conn, pid)
    log(ctx, ctx.user, "Dispensation modifiée", "%s le %s" % (p["nom_prenom"], date_disp))
    return {"ok": True}


@route("DELETE", r"/api/dispensations/(\d+)", perm="disp.delete")
def api_disp_delete(ctx):
    did = int(ctx.args[0])
    r = ctx.conn.execute("SELECT d.date_disp, p.nom_prenom FROM dispensations d JOIN patients p ON p.id=d.patient_id "
                         "WHERE d.id=?", (did,)).fetchone()
    if not r:
        raise ApiError(404, "Dispensation introuvable")
    ctx.conn.execute("DELETE FROM dispensations WHERE id=?", (did,))
    log(ctx, ctx.user, "Dispensation supprimée", "%s du %s" % (r["nom_prenom"], r["date_disp"]))
    return {"ok": True}


# --------------------------------------------------------------------------- registre (vue papier) + exports
def reg_filter(qs):
    today = datetime.date.today()
    du = vdate(qs.get("du")) or today.replace(day=1).isoformat()
    au = vdate(qs.get("au")) or today.isoformat()
    where, params = "d.date_disp BETWEEN ? AND ?", [du, au]
    q = (qs.get("q") or "").strip()
    if q:
        where += " AND (p.nom_prenom LIKE ? OR p.ipp LIKE ? OR p.dossier_no LIKE ?)"
        params += ["%" + q + "%"] * 3
    return du, au, where, params


def registre_data(conn, qs):
    du, au, where, params = reg_filter(qs)
    base = "FROM dispensations d JOIN patients p ON p.id=d.patient_id WHERE " + where
    rows = [dict(r) for r in conn.execute(
        "SELECT d.id, d.patient_id, d.date_disp, d.prochain_rdv, d.remarques, p.ipp, p.dossier_no, p.nom_prenom "
        + base + " ORDER BY d.date_disp, d.id LIMIT %d" % (MAX_ROWS + 1), params)]
    tronque = len(rows) > MAX_ROWS
    rows = rows[:MAX_ROWS]
    byid = {r["id"]: r for r in rows}
    for r in rows:
        r["items"] = {}
    for r in conn.execute(
            "SELECT i.dispensation_id, i.medicament_id, i.quantite FROM dispensation_items i "
            "JOIN dispensations d ON d.id=i.dispensation_id JOIN patients p ON p.id=d.patient_id WHERE " + where, params):
        if r["dispensation_id"] in byid:
            byid[r["dispensation_id"]]["items"][r["medicament_id"]] = r["quantite"]
    totaux = {r["medicament_id"]: r["t"] for r in conn.execute(
        "SELECT i.medicament_id, SUM(i.quantite) AS t FROM dispensation_items i "
        "JOIN dispensations d ON d.id=i.dispensation_id JOIN patients p ON p.id=d.patient_id WHERE " + where +
        " GROUP BY i.medicament_id", params)}
    meds = [dict(r) for r in conn.execute("SELECT id, nom, unite, ordre, actif FROM medicaments ORDER BY ordre, id")]
    return {"du": du, "au": au, "rows": rows, "totaux": totaux, "medicaments": meds, "tronque": tronque}


@route("GET", r"/api/registre")
def api_registre(ctx):
    return registre_data(ctx.conn, ctx.qs)


def _safe(v):
    """Protège contre l'injection de formules dans Excel."""
    s = "" if v is None else str(v)
    if s[:1] in ("=", "@") or (s[:1] in ("+", "-") and not s[1:2].isdigit()):
        return "'" + s
    return s


def _fr_date(s):
    return "/".join(reversed(s.split("-"))) if s else ""


def _csv_response(header, rows, name):
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";", lineterminator="\r\n")
    w.writerow(header)
    for r in rows:
        w.writerow(r)
    return Raw(("\ufeff" + buf.getvalue()).encode("utf-8"), "text/csv; charset=utf-8", name)


@route("GET", r"/api/export/registre\.csv")
def api_export_registre(ctx):
    d = registre_data(ctx.conn, ctx.qs)
    meds = [m for m in d["medicaments"] if m["actif"] or d["totaux"].get(m["id"], 0) > 0]
    header = ["Date", "IPP", "N° dossier", "Nom-prénom"] + ["%s (%s)" % (m["nom"], m["unite"]) for m in meds] + ["Prochain RDV", "Remarques"]
    rows = []
    for r in d["rows"]:
        rows.append([_fr_date(r["date_disp"]), _safe(r["ipp"]), _safe(r["dossier_no"]), _safe(r["nom_prenom"])]
                    + [r["items"].get(m["id"], "") for m in meds] + [_fr_date(r["prochain_rdv"]), _safe(r["remarques"])])
    rows.append(["Total", "", "", ""] + [d["totaux"].get(m["id"], 0) for m in meds] + ["", ""])
    log(ctx, ctx.user, "Export du registre", "%s au %s" % (d["du"], d["au"]))
    return _csv_response(header, rows, "registre_%s_au_%s.csv" % (d["du"], d["au"]))


@route("GET", r"/api/export/patients\.csv")
def api_export_patients(ctx):
    rows = ctx.conn.execute(
        "SELECT p.*, d.date_disp AS derniere_visite, d.prochain_rdv FROM patients p %s ORDER BY p.nom_prenom" % DERNIERE_VISITE)
    header = ["IPP", "N° dossier", "Nom-prénom", "Sexe", "Date de naissance", "Téléphone", "Adresse", "Diabète", "HTA",
              "Actif", "Dernière visite", "Prochain RDV", "Remarques"]
    out = []
    for r in rows:
        out.append([_safe(r["ipp"]), _safe(r["dossier_no"]), _safe(r["nom_prenom"]), r["sexe"] or "",
                    _fr_date(r["date_naissance"]), _safe(r["telephone"]), _safe(r["adresse"]),
                    "oui" if r["diabete"] else "", "oui" if r["hta"] else "", "oui" if r["actif"] else "non",
                    _fr_date(r["derniere_visite"]), _fr_date(r["prochain_rdv"]), _safe(r["remarques"])])
    log(ctx, ctx.user, "Export des patients")
    return _csv_response(header, out, "patients_%s.csv" % datetime.date.today().isoformat())


# --------------------------------------------------------------------------- tableau de bord
@route("GET", r"/api/stats")
def api_stats(ctx):
    c = ctx.conn
    today = datetime.date.today()
    ajd, debut = today.isoformat(), today.replace(day=1).isoformat()

    def one(sql, p=()):
        return c.execute(sql, p).fetchone()[0]

    s = {
        "patients": one("SELECT COUNT(*) FROM patients WHERE actif=1"),
        "diabete": one("SELECT COUNT(*) FROM patients WHERE actif=1 AND diabete=1"),
        "hta": one("SELECT COUNT(*) FROM patients WHERE actif=1 AND hta=1"),
        "les_deux": one("SELECT COUNT(*) FROM patients WHERE actif=1 AND diabete=1 AND hta=1"),
        "hommes": one("SELECT COUNT(*) FROM patients WHERE actif=1 AND sexe='M'"),
        "femmes": one("SELECT COUNT(*) FROM patients WHERE actif=1 AND sexe='F'"),
        "disp_mois": one("SELECT COUNT(*) FROM dispensations WHERE date_disp BETWEEN ? AND ?", (debut, ajd)),
        "servis_mois": one("SELECT COUNT(DISTINCT patient_id) FROM dispensations WHERE date_disp BETWEEN ? AND ?", (debut, ajd)),
        "sans_visite": one("SELECT COUNT(*) FROM patients p WHERE p.actif=1 AND NOT EXISTS "
                           "(SELECT 1 FROM dispensations d WHERE d.patient_id=p.id)"),
        "mois": debut[:7],
    }
    s["totaux_mois"] = [dict(r) for r in c.execute(
        "SELECT m.id, m.nom, m.unite, COALESCE(SUM(i.quantite),0) AS total FROM medicaments m "
        "LEFT JOIN (SELECT i.medicament_id, i.quantite FROM dispensation_items i JOIN dispensations d ON d.id=i.dispensation_id "
        "WHERE d.date_disp BETWEEN ? AND ?) i ON i.medicament_id=m.id GROUP BY m.id ORDER BY m.ordre, m.id", (debut, ajd))]
    s["totaux_mois"] = [t for t in s["totaux_mois"] if t["total"] > 0]
    relance = []
    for r in c.execute(
            "SELECT p.id, p.nom_prenom, p.ipp, p.dossier_no, p.telephone, d.date_disp, d.prochain_rdv FROM patients p "
            + DERNIERE_VISITE + " WHERE p.actif=1 AND d.prochain_rdv IS NOT NULL AND d.prochain_rdv < ? "
            "ORDER BY d.prochain_rdv LIMIT 300", (ajd,)):
        row = dict(r)
        row["jours_retard"] = (today - datetime.date.fromisoformat(r["prochain_rdv"])).days
        relance.append(row)
    s["a_relancer"] = relance
    return s


# --------------------------------------------------------------------------- sauvegarde et journal (admin)
@route("GET", r"/api/backup", perm="backup")
def api_backup(ctx):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    tmp = os.path.join(BACKUP_DIR, "tmp_%s.db" % secrets.token_hex(4))
    try:
        copy_db(tmp)
        with open(tmp, "rb") as f:
            data = f.read()
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    log(ctx, ctx.user, "Sauvegarde téléchargée")
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
    return Raw(data, "application/octet-stream", "registre_sauvegarde_%s.db" % stamp)


@route("GET", r"/api/journal", perm="journal")
def api_journal(ctx):
    return [dict(r) for r in ctx.conn.execute("SELECT ts, utilisateur, action, detail FROM journal ORDER BY id DESC LIMIT 300")]


# --------------------------------------------------------------------------- serveur HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "RegistreMC/1.0"

    def log_message(self, *args):
        pass

    def do_GET(self):
        self.process("GET")

    def do_POST(self):
        self.process("POST")

    def do_PUT(self):
        self.process("PUT")

    def do_DELETE(self):
        self.process("DELETE")

    def session_token(self):
        raw = self.headers.get("Cookie", "")
        try:
            c = cookies.SimpleCookie(raw)
        except cookies.CookieError:
            return None
        return c["sid"].value if "sid" in c else None

    def auth(self, conn):
        tok = self.session_token()
        if not tok:
            return None
        row = conn.execute("SELECT u.*, s.expires FROM sessions s JOIN users u ON u.id=s.user_id "
                           "WHERE s.token=? AND u.active=1", (tok,)).fetchone()
        if not row or row["expires"] < time.time():
            return None
        conn.execute("UPDATE sessions SET expires=? WHERE token=?", (time.time() + SESSION_TTL, tok))
        return row

    def read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 1_000_000:
            raise ApiError(413, "Requête trop volumineuse")
        raw = self.rfile.read(n) if n else b""
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "Requête invalide")
        if not isinstance(data, dict):
            raise ApiError(400, "Requête invalide")
        return data

    def process(self, method):
        cookie_out = None
        try:
            url = urlparse(self.path)
            path = url.path
            body = self.read_json() if method in ("POST", "PUT") else {}
            if not path.startswith("/api/"):
                if method != "GET":
                    raise ApiError(405, "Méthode non autorisée")
                return self.respond(self.static(path))
            qs = {k: v[0] for k, v in parse_qs(url.query).items()}
            match = None
            path_exists = False
            for m, rx, fn, perm, public in ROUTES:
                mt = rx.match(path)
                if mt:
                    path_exists = True
                    if m == method:
                        match = (fn, perm, public, mt)
                        break
            if not match:
                raise ApiError(405 if path_exists else 404, "Ressource introuvable")
            fn, perm, public, mt = match
            conn = db()
            try:
                user = None
                if not public:
                    user = self.auth(conn)
                    if not user:
                        raise ApiError(401, "Session expirée, reconnectez-vous")
                    if user["must_change"] and fn.__name__ not in ("api_me", "api_password", "api_logout"):
                        raise ApiError(403, "Vous devez d'abord changer votre mot de passe", {"must_change": True})
                    if perm:
                        require(user, perm)
                ctx = Ctx(self, conn, user, qs, body, mt.groups())
                res = fn(ctx)
                conn.commit()
                cookie_out = ctx.cookie
            finally:
                conn.close()
            self.respond(res, cookie=cookie_out)
        except ApiError as e:
            payload = {"error": e.message}
            payload.update(e.extra)
            self.respond(payload, status=e.status)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            try:
                self.respond({"error": "Erreur interne du serveur"}, status=500)
            except Exception:
                pass

    def static(self, path):
        if path in ("/", "/index.html"):
            with open(os.path.join(BASE_DIR, "index.html"), "rb") as f:
                return Raw(f.read(), "text/html; charset=utf-8")
        raise ApiError(404, "Page introuvable")

    def respond(self, res, status=200, cookie=None):
        if isinstance(res, Raw):
            data, ctype, fname = res.data, res.ctype, res.filename
        else:
            data = json.dumps(res, ensure_ascii=False).encode("utf-8")
            ctype, fname = "application/json; charset=utf-8", None
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:")
        if fname:
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % fname)
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(data)


def local_addresses():
    addrs = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        addrs.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        for a in socket.gethostbyname_ex(socket.gethostname())[2]:
            if a not in addrs and not a.startswith("127."):
                addrs.append(a)
    except Exception:
        pass
    return addrs


def main():
    print("=" * 62)
    print("  REGISTRE DES MALADIES CHRONIQUES - Centre de santé")
    print("=" * 62)
    init_db()
    auto_backup()
    threading.Thread(target=backup_loop, daemon=True).start()
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError as e:
        print("\n  Impossible de démarrer sur le port %d : %s" % (PORT, e))
        print("  Le logiciel est peut-être déjà ouvert dans une autre fenêtre.")
        sys.exit(1)
    srv.daemon_threads = True
    print("\n  Le logiciel est démarré. NE FERMEZ PAS cette fenêtre.\n")
    print("  Sur CET ordinateur :        http://localhost:%d" % PORT)
    for a in local_addresses():
        print("  Depuis les AUTRES postes :  http://%s:%d" % (a, PORT))
    print("\n  Base de données : %s" % DB_PATH)
    print("  Ctrl+C pour arrêter.\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur.")
    finally:
        srv.server_close()


if __name__ == "__main__":
    main()
